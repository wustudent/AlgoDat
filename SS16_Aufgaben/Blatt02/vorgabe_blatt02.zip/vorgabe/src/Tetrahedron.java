public class Tetrahedron {
    // TODO: Vererbungshierarchie und Implementation
}

